To run the code:
1. Download the .zip file
2. Extract the .zip file
3. From the homewords folder, run python homework1.py
5. The output is produced on the shell

Note: I have used python 36 for my implementation
Note: Random seed is set to 687
Note: numpy, random, and matplotlib.pyplot are the modules required to be installed